# Face-Recognition-Based-Attendance-System-master
face recognition based attendence system
Hello imran,haider and Atif 
I have just created a software based upon the 
facial recognition attendence system that is successfully working 
to operate it folow the following instructions
1: run the program GUI interface is appered 
2: input your unique id and name 
3: click on take images
4: after taking images click on train images
5: next you have to track it on different images 
6: it will recognize you ultimately
